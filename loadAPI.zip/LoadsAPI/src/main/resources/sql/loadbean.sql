"shipperid","date","loading_point","nooftruck","product_type","truck_type","unloading_point","weight","comment_cid"
11,"2021-08-12","pune",1,"Chemical","canter truck","Delhi","100kg",10
13,"2021-08-12","mumbai",1,"Elctronics","canter truck","Delhi","200kg",12
15,"2021-08-12","pune",3,"computers","canter truck","Delhi","1000kg",14
