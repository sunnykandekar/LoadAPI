package com.LoadsAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoadsApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoadsApiApplication.class, args);
	}

}
